<?php
defined('_JEXEC') or die;
// Mapping-Feld entfernt – dieses Layout wird nicht mehr verwendet.
