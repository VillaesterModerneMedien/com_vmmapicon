// Deprecated: API Field Mapping wurde entfernt. Datei ohne Funktion.

