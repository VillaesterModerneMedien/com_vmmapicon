-- Uninstall
DROP TABLE IF EXISTS `#__vmmapicon_apis`;
DROP TABLE IF EXISTS `#__vmmapicon_mapping`;

