Array
(
[0] => stdClass Object
(
[id] => 549
[type] => articles
[title] => Suedlink - Stromtrasse unter Tage
[alias] => suedlink-stromtrasse-unter-tage
[state] => 0
[access] => 1
[created] => 2024-05-15 10:30:58
[created_by] => 545
[modified] => 2024-10-14 10:48:17
[featured] => 0
[language] => de-DE
[hits] => 0
[publish_up] => 2024-05-15 06:30:11
[publish_down] =>
[note] =>
[image_intro] =>
[image_intro_alt] =>
[image_fulltext] =>
[image_fulltext_alt] =>
[metakey] =>
[metadesc] =>
[metadata_robots] =>
[metadata_author] =>
[metadata_rights] =>
[version] => 2
[featured_up] =>
[featured_down] =>
[typeAlias] => com_content.article
[text] => <p><strong><strong>Höchstspannungsgleichstromübertragungsleitung.<br /></strong></strong></p>
<strong><br />Aktueller Fortschritt im Projekt<br /></strong>
[testfeld] =>
[bilder] => Array
(
)

            [article_field] => 
            [category_id] => 9
            [author_id] => 545
            [tags_ids] => Array
                (
                )

            [raw] => {"type":"articles","id":"549","attributes":{"id":549,"asset_id":735,"title":"Suedlink - Stromtrasse unter Tage","alias":"suedlink-stromtrasse-unter-tage","state":0,"access":1,"created":"2024-05-15 10:30:58","created_by":545,"created_by_alias":"","modified":"2024-10-14 10:48:17","featured":0,"language":"de-DE","hits":0,"publish_up":"2024-05-15 06:30:11","publish_down":null,"note":"","images":{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""},"metakey":"","metadesc":"","metadata":{"robots":"","author":"","rights":"","xreference":""},"version":2,"featured_up":null,"featured_down":null,"typeAlias":"com_content.article","text":"<p><strong><strong>Höchstspannungsgleichstromübertragungsleitung.<br /></strong></strong></p>\r\n <strong><br />Aktueller Fortschritt im Projekt<br /></strong>","testfeld":"","bilder":"","article-field":"","tags":[]},"relationships":{"category":{"data":{"type":"categories","id":"9"}},"created_by":{"data":{"type":"users","id":"545"}},"tags":{"data":[]}}}
        )

)
