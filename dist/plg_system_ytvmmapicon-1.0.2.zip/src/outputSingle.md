Array
(
[0] => stdClass Object
(
[id] => 549
[type] =>
[title] => Suedlink - Stromtrasse unter Tage
[alias] => suedlink-stromtrasse-unter-tage
[state] => 0
[access] => 1
[created] => 2024-05-15 10:30:58
[created_by] => 545
[modified] => 2024-10-14 10:48:17
[featured] => 0
[language] => de-DE
[hits] => 0
[publish_up] => 2024-05-15 06:30:11
[publish_down] =>
[note] =>
[image_intro] =>
[image_intro_alt] =>
[image_fulltext] =>
[image_fulltext_alt] =>
[metakey] =>
[metadesc] =>
[metadata_robots] =>
[metadata_author] =>
[metadata_rights] =>
[version] => 2
[featured_up] =>
[featured_down] =>
[typeAlias] => com_content.article
[text] => <p><strong><strong>Höchstspannungsgleichstromübertragungsleitung.<br /></strong></strong></p>
<strong><br />Aktueller Fortschritt im Projekt<br /></strong>
[testfeld] =>
[bilder] => Array
(
)

            [article_field] => 
            [category_id] => 
            [author_id] => 
            [tags_ids] => Array
                (
                )

            [raw] => {"typeAlias":"com_content.article","id":549,"asset_id":735,"title":"Suedlink - Stromtrasse unter Tage","alias":"suedlink-stromtrasse-unter-tage","state":0,"created":"2024-05-15 10:30:58","created_by":545,"created_by_alias":"","modified":"2024-10-14 10:48:17","modified_by":545,"publish_up":"2024-05-15 06:30:11","publish_down":null,"images":{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""},"urls":{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""},"version":2,"metakey":"","metadesc":"","access":1,"hits":0,"metadata":{"robots":"","author":"","rights":"","xreference":""},"featured":0,"language":"de-DE","note":"","tags":[],"featured_up":null,"featured_down":null,"text":"<p><strong><strong>Höchstspannungsgleichstromübertragungsleitung.<br /></strong></strong></p>\r\n <strong><br />Aktueller Fortschritt im Projekt<br /></strong>","testfeld":"","bilder":"","article-field":""}
        )

)
